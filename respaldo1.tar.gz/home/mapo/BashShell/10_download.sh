#!/bin/bash
# Programa para ejemplificar el uso de descarga desde internet usando el comando wget

echo "Descargar información de Internet"
wget https://downloads.apache.org/tomcat/tomcat-8/v8.5.57/bin/apache-tomcat-8.5.57.zip 

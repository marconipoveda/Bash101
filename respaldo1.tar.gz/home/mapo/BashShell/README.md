# bash101

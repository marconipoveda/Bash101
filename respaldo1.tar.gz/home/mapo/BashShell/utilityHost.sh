#!/bin/bash
#Reto 1

option=2
result=4

echo "El valor de option es: $option"
echo "El valor de result es: $result"

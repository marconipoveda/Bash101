#!/bin/bash
echo Se pasaron $# parámetros
echo El último parámetro es ${!#}

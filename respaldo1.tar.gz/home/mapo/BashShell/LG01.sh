#!/bin/bash
echo Se pasaron $# parámetros

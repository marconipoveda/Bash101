#!/bin/bash
#Programa para revisar la creación de variables

echo "Del otro script viene la variable nombre: $nombre"
